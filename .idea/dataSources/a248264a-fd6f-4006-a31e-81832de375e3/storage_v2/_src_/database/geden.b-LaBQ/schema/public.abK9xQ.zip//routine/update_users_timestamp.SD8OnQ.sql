create function update_users_timestamp()
  returns trigger
language plpgsql
as $$
BEGIN
  IF NEW.updated_date = OLD.updated_date THEN
    NEW.updated_date = now();
  END IF;
  RETURN NEW;
END;
$$;

alter function update_users_timestamp()
  owner to postgres;

